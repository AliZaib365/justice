document.addEventListener('DOMContentLoaded', () => {
  const slides = document.querySelectorAll('.hero-slide');
  const dotsContainer = document.querySelector('.hero-dots');
  let current = 0;
  let interval;
  function createDots() {
    slides.forEach((_, idx) => {
      const dot = document.createElement('span');
      dot.classList.add('dot');
      if (idx === 0) dot.classList.add('active');
      dot.addEventListener('click', () => showSlide(idx));
      dotsContainer.appendChild(dot);
    });
  }
  function showSlide(idx) {
    slides[current].classList.remove('active');
    dotsContainer.children[current].classList.remove('active');
    current = idx;
    slides[current].classList.add('active');
    dotsContainer.children[current].classList.add('active');
    resetInterval();
  }
  function nextSlide() {
    let next = (current + 1) % slides.length;
    showSlide(next);
  }
  function resetInterval() {
    clearInterval(interval);
    interval = setInterval(nextSlide, 4000);
  }
  createDots();
  interval = setInterval(nextSlide, 4000);
});
document.addEventListener('DOMContentLoaded', function () {
  const counters = document.querySelectorAll('.jc-counter-number');
  let animated = false;

  function animateCounters() {
    counters.forEach(counter => {
      const target = +counter.getAttribute('data-target');
      const duration = 1400;
      const frameRate = 18;
      let current = 0;
      const steps = Math.ceil(duration / frameRate);
      const increment = Math.ceil(target / steps);
      function update() {
        current += increment;
        if (current >= target) {
          counter.textContent = target;
        } else {
          counter.textContent = current;
          setTimeout(update, frameRate);
        }
      }
      update();
    });
  }
  function isSectionInView() {
    const section = document.querySelector('.jc-counter-section');
    const rect = section.getBoundingClientRect();
    return rect.top < window.innerHeight && rect.bottom > 0;
  }
  function onScroll() {
    if (!animated && isSectionInView()) {
      animateCounters();
      animated = true;
      window.removeEventListener('scroll', onScroll);
    }
  }
  window.addEventListener('scroll', onScroll);
  onScroll();
});
document.addEventListener('DOMContentLoaded', function () {
  const slides = document.querySelectorAll('.jc-expert-team-slide');
  const dots = document.querySelectorAll('.jc-expert-team-dot');
  const leftArrow = document.querySelector('.jc-expert-team-slider-arrow-left');
  const rightArrow = document.querySelector('.jc-expert-team-slider-arrow-right');
  const slidesToShow = 3;
  let currentIndex = 0;
  function showSlides(idx) {
    slides.forEach((slide, i) => {
      slide.style.display = (i >= idx && i < idx + slidesToShow) ? 'flex' : 'none';
    });
    dots.forEach((dot, i) => {
      if (i === idx) {
        dot.classList.add('active');
      } else {
        dot.classList.remove('active');
      }
    });
  }

  function prevSlide() {
    if (currentIndex > 0) {
      currentIndex--;
      showSlides(currentIndex);
    }
  }
  function nextSlide() {
    if (currentIndex < slides.length - slidesToShow) {
      currentIndex++;
      showSlides(currentIndex);
    }
  }
  leftArrow.addEventListener('click', prevSlide);
  rightArrow.addEventListener('click', nextSlide);
  dots.forEach((dot, i) => {
    dot.addEventListener('click', () => {
      currentIndex = i;
      showSlides(currentIndex);
    });
  });
  showSlides(0);
});
const menuToggle = document.getElementById('menuToggle');
const sidebar = document.getElementById('sidebar');
const closeSidebar = document.getElementById('closeSidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');

// Open sidebar
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = "block";
  document.body.style.overflow = "hidden";
}
// Close sidebar
function closeSidebarFn() {
  sidebar.classList.remove('open');
  sidebarOverlay.style.display = "none";
  document.body.style.overflow = "";
}

// Click events
menuToggle.addEventListener('click', openSidebar);
menuToggle.addEventListener('keydown', e => {
  if (e.key === "Enter" || e.key === " ") openSidebar();
});
closeSidebar.addEventListener('click', closeSidebarFn);
sidebarOverlay.addEventListener('click', closeSidebarFn);

// ESC key closes sidebar
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && sidebar.classList.contains('open')) {
    closeSidebarFn();
  }
});
 document.querySelector('.about-tjc-play-btn').addEventListener('click', function() {
    this.style.display = 'none';
  });